# **Non-Lethal Company**

## **Work for The Company with the whole family!**

**This mod disables all blood effects and dismemberment.**

Queasy at the sight of blood? Want to play but you or a loved one doesn't appreciate the violence? Simply want a cleaner experience? Look no further!

This mod aims to remove all sources of blood, gore, and dismemberment from the game. I believe all bases are covered, but if you find something that's slipped through the cracks, shoot me a message and I'll update it ASAP.


## **Encounter an issue?**

Send me a message on Discord @tanmang, or an email at mangomango.dev@gmail.com



~ Requested by Octez ~
